package dto;

import java.util.Date;

public class pddetails {
	
	//private String diagnosisid;
	//private String mrn;
	private String description;
	private String first_name;
	private String last_name;
	private Date diagnosisdate;
	
	
	public pddetails() {
		
	}


	public pddetails(String description, String first_name, String last_name, Date diagnosisdate) {
		super();
		this.description = description;
		this.first_name = first_name;
		this.last_name = last_name;
		this.diagnosisdate = diagnosisdate;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public String getFirst_name() {
		return first_name;
	}


	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}


	public String getLast_name() {
		return last_name;
	}


	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}


	public Date getDiagnosisdate() {
		return diagnosisdate;
	}


	public void setDiagnosisdate(Date diagnosisdate) {
		this.diagnosisdate = diagnosisdate;
	}








	


	
	

}
