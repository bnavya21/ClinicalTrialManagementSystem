package com.example.demo.service;
import java.util.List;

import com.example.demo.model.Patient;

public interface Patientservice {
	List <Patient> findAll();
	void save(Patient patient);
	List<Patient> findByUser_id(String user_id);
	void delete(String id);

}





/*
import net.guides.springboot.jparepository.model.Employee;

public interface EmployeeService {

    List < Employee > findAll();

    void save(Employee employee);

    Optional < Employee > findById(Long id);

    void delete(long id);
}
*/