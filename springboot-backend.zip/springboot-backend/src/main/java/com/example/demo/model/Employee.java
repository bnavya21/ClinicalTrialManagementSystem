package com.example.demo.model;

//import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name ="Employee")
public class Employee {
	@Id
	@GeneratedValue(strategy =GenerationType.IDENTITY)
	private String emp_id;
	private String first_name;
	private String last_name;
	private String department;
	private String gender;
	private String address;
	private String mobile;
	private String user_id;
	private String password;
	private String mail;
	private String role;
	

	  public Employee() {
		  
	  }
	



	public Employee(String first_name, String last_name, String department, String gender, String address,
			String mobile, String user_id, String password, String mail, String role) {
		super();
		this.first_name = first_name;
		this.last_name = last_name;
		this.department = department;
		this.gender = gender;
		this.address = address;
		this.mobile = mobile;
		this.user_id = user_id;
		this.password = password;
		this.mail = mail;
		this.role = role;
	}




	public String getEmp_id() {
		return emp_id;
	}




	public void setEmp_id(String emp_id) {
		this.emp_id = emp_id;
	}




	public String getFirst_name() {
		return first_name;
	}




	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}




	public String getLast_name() {
		return last_name;
	}




	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}




	public String getDepartment() {
		return department;
	}




	public void setDepartment(String department) {
		this.department = department;
	}




	public String getGender() {
		return gender;
	}




	public void setGender(String gender) {
		this.gender = gender;
	}




	public String getAddress() {
		return address;
	}




	public void setAddress(String address) {
		this.address = address;
	}




	public String getMobile() {
		return mobile;
	}




	public void setMobile(String mobile) {
		this.mobile = mobile;
	}




	public String getUser_id() {
		return user_id;
	}




	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}




	public String getPassword() {
		return password;
	}




	public void setPassword(String password) {
		this.password = password;
	}




	public String getMail() {
		return mail;
	}




	public void setMail(String mail) {
		this.mail = mail;
	}




	public String getRole() {
		return role;
	}




	public void setRole(String role) {
		this.role = role;
	}




	
	
	
}
