package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.model.ClinicalTrial;
import com.example.demo.model.Patient;
@Repository
public interface ClinicalTrialRespository extends JpaRepository<ClinicalTrial,String> {
	//to get the disease groups
	@Query(value="select p.diseasegroup from ClinicalTrial p GROUP BY diseasegroup")
	List<String> findBydiseasegroup();
	
	//to get the diseases list given the disease group
	@Query(value="select distinct p.disease from ClinicalTrial p where p.diseasegroup=:diseasegroup")
	List<String> findAlldiseasesbygroup(String diseasegroup);
	
	//to get the trials list given the disease name
	@Query(value="select p from ClinicalTrial p where p.disease=:disease")
	List<ClinicalTrial> findAllTrialBydisease(String disease);
	
	//to get the trail info give the trial name
	@Query(value="select p from ClinicalTrial p where p.name=:name")
	ClinicalTrial findTrialByname(String name);
	
	//to get the list of all trial names
	@Query(value="select p.name from ClinicalTrial p")
	List<String> findAllTrials();
	
	//to the list of patients 
	@Query(value="select distinct p1 from Patient p1 join PatientDiagnosis p on p1.mrn =p.mrn join ClinicalTrial c where c.name=:name")
	List<Patient> findPatients(String name);
}
