package com.example.demo.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="clinicaltrial")
public class ClinicalTrial {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private String trial_id;
	private String name;
	private String description;
	private Date start_date;
	private String status;
	private String duration;
	private String diseasegroup;
	private String investigator;
	private String disease;
	
	public ClinicalTrial() {
		
	}

	public ClinicalTrial(String name, String description, Date start_date, String status, 
			 String duration, String diseasegroup, String investigator, String disease) {
		super();
		this.name = name;
		this.description = description;
		this.start_date = start_date;
		this.status = status;
		
		this.duration = duration;
		this.diseasegroup = diseasegroup;
		this.investigator = investigator;
		this.disease = disease;
	}

	public String getTrial_id() {
		return trial_id;
	}

	public void setTrial_id(String trial_id) {
		this.trial_id = trial_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getStart_date() {
		return start_date;
	}

	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	
	

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public String getDiseasegroup() {
		return diseasegroup;
	}

	public void setDiseasegroup(String diseasegroup) {
		this.diseasegroup = diseasegroup;
	}

	public String getInvestigator() {
		return investigator;
	}

	public void setInvestigator(String investigator) {
		this.investigator = investigator;
	}

	public String getDisease() {
		return disease;
	}

	public void setDisease(String disease) {
		this.disease = disease;
	}
	
	

}
