package com.example.demo.repository;


import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Patient;

@Repository
@Qualifier(value = "PatientRespository")
public interface PatientRespository extends JpaRepository<Patient,Long> {

	@Query(value="select p from Patient p where p.user_id =:user_id")
	 Patient findByUser_id(String user_id);
	 @Query(value="select p from Patient p where p.mrn =:mrn")
	 Patient findById(String mrn);
	

}

