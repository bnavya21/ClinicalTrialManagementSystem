package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.PatientDiagnosis;
import com.example.demo.repository.PatientDiagnosisRepository;

import dto.pddetails;

@RestController
@RequestMapping("/api/vi/")
public class PatientDiagnosisController {
	
	@Autowired
	private  PatientDiagnosisRepository pdrepository;
	
	//get patient's all diagnosis
	@GetMapping("/PatientDiagnosis")
	public ResponseEntity<List<PatientDiagnosis>> getPatientAllDiagnosis(String mrn){
	 List<PatientDiagnosis> patientdiagnosis =pdrepository.findAllBymrn(mrn);
	 return ResponseEntity.ok(patientdiagnosis);
	}
	
	 @GetMapping("/patientdiagnosis/{pdid}")
	 public ResponseEntity<PatientDiagnosis> getPatientDiagnosis(@PathVariable Long pdid){
		 PatientDiagnosis patientdiagnosis = pdrepository.findById(pdid).orElseThrow();
		 return ResponseEntity.ok(patientdiagnosis);
	 }
	 //add diagnosis of a a patient
	 @PostMapping("/PatientDiagnosis")
		public PatientDiagnosis AddPatientDiagnosis(@RequestBody PatientDiagnosis pd ) {
			return pdrepository.save(pd);
}
	 //custom query for join
	 @GetMapping("/patientdiag")
	 public ResponseEntity<List<pddetails>> getdiag(String mrn){
		 List<pddetails> ddetails = pdrepository.findAlld(mrn);
		 return ResponseEntity.ok(ddetails);
	 }
}
