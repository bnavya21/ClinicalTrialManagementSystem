package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.demo.model.Patient;
import com.example.demo.model.TrialConditions;

public interface TrialConditionsRepository extends JpaRepository<TrialConditions, Long>{
	
	@Query(value="select p1 from Patient p1 where p1.mrn in (select m.mrn from PatientMedication m join TrialConditions t on  m.med_id=t.itemid where t.itemtype=2  and t.trialname=:name and m.mrn in ( select p.mrn from PatientDiagnosis p join TrialConditions t on p.diag_id=t.itemid where itemtype=1 and t.trialname=:name))") 
	List<Patient> finddiag(String name);

}
