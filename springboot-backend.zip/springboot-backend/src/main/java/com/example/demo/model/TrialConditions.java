package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="trialcondition")
public class TrialConditions {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long cid;
	private String trialname;
	private Long itemtype;
	private String itemid;
	
	
	public TrialConditions(String trialname, Long itemtype, String itemid) {
		super();
		this.trialname = trialname;
		this.itemtype = itemtype;
		this.itemid = itemid;
	}
	
	public Long getCid() {
		return cid;
	}
	public void setCid(Long cid) {
		this.cid = cid;
	}
	public String getTrialname() {
		return trialname;
	}
	public void setTrialname(String trialname) {
		this.trialname = trialname;
	}
	public Long getItemtype() {
		return itemtype;
	}
	public void setItemtype(Long itemtype) {
		this.itemtype = itemtype;
	}
	public String getItemid() {
		return itemid;
	}
	public void setItemid(String itemid) {
		this.itemid = itemid;
	}
	
	

}
