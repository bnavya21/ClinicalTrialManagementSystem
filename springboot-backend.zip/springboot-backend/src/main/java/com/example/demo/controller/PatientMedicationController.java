package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.PatientDiagnosis;
import com.example.demo.model.PatientMedication;
import com.example.demo.repository.PatientMedicationRepository;

import dto.pmdetails;

@RestController
@RequestMapping("/api/vi/")
public class PatientMedicationController {
	
	@Autowired
	private  PatientMedicationRepository pmrepository;
	
	//get patient's all diagnosis
	@GetMapping("/PatientMedication")
	public ResponseEntity<List<pmdetails>> getPatientAllMedication(String mrn){
	 List<pmdetails> pmdetails =pmrepository.findAllBymrn(mrn);
	 return ResponseEntity.ok(pmdetails);
	}
	//add  patient medication
	 @PostMapping("/PatientMedication")
		public PatientMedication AddPatientMedication(@RequestBody PatientMedication pm ) {
			return pmrepository.save(pm);
}
}
