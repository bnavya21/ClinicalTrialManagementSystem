package com.example.demo.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="patientdiagnosis")
public class PatientDiagnosis {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long pdid;
	@Column(name="mrn")
	private String mrn;
	@Column(name="diag_id")
	private String diag_id;
	@Column(name="emp_id")
	private String emp_id;
	@Column(name="diagnosisdate")
	private Date diagnosisdate;
	
	public PatientDiagnosis() {
		
	}

	public PatientDiagnosis(String mrn, String diag_id, String emp_id, Date diagnosisdate) {
		super();
		this.mrn = mrn;
		this.diag_id = diag_id;
		this.emp_id = emp_id;
		this.diagnosisdate = diagnosisdate;
	}

	public Long getPdid() {
		return pdid;
	}

	public void setPdid(Long pdid) {
		this.pdid = pdid;
	}

	public String getMrn() {
		return mrn;
	}

	public void setMrn(String mrn) {
		this.mrn = mrn;
	}

	public String getDiag_id() {
		return diag_id;
	}

	public void setDiag_id(String diag_id) {
		this.diag_id = diag_id;
	}

	public String getEmp_id() {
		return emp_id;
	}

	public void setEmp_id(String emp_id) {
		this.emp_id = emp_id;
	}

	public Date getDiagnosisDate() {
		return diagnosisdate;
	}

	public void setDiagnosisDate(Date diagnosisdate) {
		this.diagnosisdate = diagnosisdate;
	}
	
	
}
