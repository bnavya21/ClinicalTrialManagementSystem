package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="patientmedication")
public class PatientMedication {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long pmid;
	private String mrn;
	private String med_id;
	private String emp_id;
	
	
	public PatientMedication() {
		
	}
	

	public PatientMedication(String mrn, String med_id, String emp_id) {
		super();
		this.mrn = mrn;
		this.med_id = med_id;
		this.emp_id = emp_id;
		
	}


	public Long getPmid() {
		return pmid;
	}

	public void setPmid(Long pmid) {
		this.pmid = pmid;
	}

	public String getMrn() {
		return mrn;
	}

	public void setMrn(String mrn) {
		this.mrn = mrn;
	}

	public String getMed_id() {
		return med_id;
	}

	public void setMed_id(String med_id) {
		this.med_id = med_id;
	}

	public String getEmp_id() {
		return emp_id;
	}

	public void setEmp_id(String emp_id) {
		this.emp_id = emp_id;
	}

	
	
}

	
