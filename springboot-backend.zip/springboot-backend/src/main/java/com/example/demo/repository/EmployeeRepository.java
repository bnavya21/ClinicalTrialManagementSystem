package com.example.demo.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.demo.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee,Long> {

	@Query(value="select p from Employee p where p.user_id =:user_id")
	Employee findByUser_id(String user_id);
	
	@Query(value="select p from Employee p where p.emp_id=:emp_id")
	Employee findById(String emp_id);

}
