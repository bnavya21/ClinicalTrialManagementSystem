package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Patient;
import com.example.demo.repository.TrialConditionsRepository;

@RestController
@RequestMapping("/api/vi/")
public class TrialConditionsController {
	
	@Autowired
	private TrialConditionsRepository tcrepository;
	
	@GetMapping("/trialconditionforpatients")
	public List<Patient> getQualifiedPatients(String name){
		return (List<Patient>) tcrepository.finddiag(name);
	}

}
