package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.service.EmailSenderService;

@RestController
@RequestMapping("/api/vi")
public class EmailController {
	@Autowired
	EmailSenderService emailSenderService;

	@GetMapping("/sendEmail")
	public String sendEmail(String to,String text) {
		return emailSenderService.sendEmail(to,text);
	}

}
