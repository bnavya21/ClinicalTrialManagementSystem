package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.model.PatientDiagnosis;

import dto.pddetails;
@Repository
//@Qualifier(value="PatientDiagnosisRepository")
public interface PatientDiagnosisRepository extends JpaRepository<PatientDiagnosis,Long>{
//@Modifying
//@Transactional
	@Query(value="select p from PatientDiagnosis p where p.mrn=:mrn")
	List<PatientDiagnosis> findAllBymrn(String mrn);
//writing a custom query
	@Query(value="select new dto.pddetails(e.first_name,e.last_name,d.description,p.diagnosisdate) from PatientDiagnosis p join Diagnosis d on p.diag_id=d.diagnosisid join Employee e on e.emp_id=p.emp_id where p.mrn=:mrn")
	List<pddetails> findAlld(String mrn);
}
