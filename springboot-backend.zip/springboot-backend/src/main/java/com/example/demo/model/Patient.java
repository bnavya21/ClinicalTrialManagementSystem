package com.example.demo.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="Patient")
public class Patient {
	@Id
	@GeneratedValue(strategy =GenerationType.IDENTITY)
	private String mrn;
	private String first_name;
	private String last_name;
	private Date date_of_birth;
	private String gender;
	private String address;
	private String mobile;
	private String user_id;
	private String password;
	private String mail;
	

	  public Patient() {
		  
	  }


	public Patient(String first_name, String last_name, Date date_of_birth, String gender, String address,
			String mobile, String user_id, String password, String mail) {
		super();
		this.first_name = first_name;
		this.last_name = last_name;
		this.date_of_birth = date_of_birth;
		this.gender = gender;
		this.address = address;
		this.mobile = mobile;
		this.user_id = user_id;
		this.password = password;
		this.mail = mail;
	}


	public String getMrn() {
		return mrn;
	}


	public void setMrn(String mrn) {
		this.mrn = mrn;
	}


	public String getFirst_name() {
		return first_name;
	}


	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}


	public String getLast_name() {
		return last_name;
	}


	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}


	public Date getDate_of_birth() {
		return date_of_birth;
	}


	public void setDate_of_birth(Date date_of_birth) {
		this.date_of_birth = date_of_birth;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getMobile() {
		return mobile;
	}


	public void setMobile(String mobile) {
		this.mobile = mobile;
	}


	public String getUser_id() {
		return user_id;
	}


	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getMail() {
		return mail;
	}


	public void setMail(String mail) {
		this.mail = mail;
	}
	
	
	
	
}
