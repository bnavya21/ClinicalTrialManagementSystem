package com.example.demo.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.demo.model.PatientMedication;

import dto.pmdetails;

public interface PatientMedicationRepository extends JpaRepository<PatientMedication,Long> {
	
	//@Query(value = "select p from PatientMedication p where p.mrn=:mrn ")
	//List<PatientMedication> findAllBymrn (String mrn);
	
	@Query(value="select new dto.pmdetails(e.first_name,e.last_name,m.name) from Employee e join PatientMedication p on p.emp_id=e.emp_id join Medication m on p.med_id=m.med_id where p.mrn=:mrn")
	List<pmdetails> findAllBymrn(String mrn);
}
