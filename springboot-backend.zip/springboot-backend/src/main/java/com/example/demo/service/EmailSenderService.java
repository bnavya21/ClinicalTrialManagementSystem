package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
@Service
public class EmailSenderService {
	@Autowired
	JavaMailSender javaMailSender;

	public String sendEmail(String to,String text) {
		SimpleMailMessage message = new SimpleMailMessage();
		
		message.setFrom("clinicaltrialmanagementsystem@gmail.com");
		message.setTo(to);
		message.setSubject("Clinical Trial Notification");
		message.setText(text);
		
		javaMailSender.send(message);
		
		return "Mail sent successfully";
	}

}
