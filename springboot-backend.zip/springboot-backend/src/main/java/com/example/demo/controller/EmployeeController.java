package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Employee;
import com.example.demo.model.Patient;
import com.example.demo.repository.EmployeeRepository;


@RestController
@RequestMapping("/api/vi")
public class EmployeeController {

	@Autowired
	private EmployeeRepository employeerepository;
	
		//creating patient rest api
		@PostMapping("/Employee")
		public Employee RegisterEmployee(@RequestBody Employee employee ) {
			return employeerepository.save(employee);
		}
		
		//get all employees
		@GetMapping("/Employees")
		public List<Employee> getAllEmployees(){
			return employeerepository.findAll();
	}
		
		//get employee by user_id
		 @GetMapping("/Employee")
		    public ResponseEntity<Employee> getUsersByUsername(String user_id) {
		            Employee employee= employeerepository.findByUser_id(user_id);
		            return ResponseEntity.ok().body(employee);
		        
		 }
		 
		 //update employee using emp_id
		 @PutMapping("/Employee/{emp_id}")
		 public ResponseEntity<Employee> updateEmployee(@PathVariable String emp_id,@RequestBody Employee employeedetails ){
			 Employee employee = employeerepository.findById(emp_id);//orElseThrow(() -> new ResourceNotFound("Patient not found for this id :: " + user_id));
			 	employee.setFirst_name(employeedetails.getFirst_name());
			 	employee.setAddress(employeedetails.getAddress());
			 	employee.setLast_name(employeedetails.getLast_name());
			 	employee.setMail(employeedetails.getMail());
			 	employee.setPassword(employeedetails.getPassword());
			 	employee.setUser_id(employeedetails.getUser_id());
			 	employee.setDepartment(employeedetails.getDepartment());
			 	employee.setRole(employeedetails.getRole());
			 	employee.setMobile(employeedetails.getMobile());
			 	employee.setGender(employeedetails.getGender());
			 	Employee updateEmployee = employeerepository.save(employee);
			 	return ResponseEntity.ok(updateEmployee);
		 }
		 
		
}

