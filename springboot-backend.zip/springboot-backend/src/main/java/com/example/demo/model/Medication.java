package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Medication")
public class Medication {
	
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private String med_id;
	private String name;
	
	public Medication() {
		
	}

	public Medication(String name) {
		super();
		this.name = name;
	}

	public String getMed_id() {
		return med_id;
	}

	public void setMed_id(String med_id) {
		this.med_id = med_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	

}
