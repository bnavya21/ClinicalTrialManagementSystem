package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.ClinicalTrial;
import com.example.demo.model.Patient;
import com.example.demo.repository.ClinicalTrialRespository;

@RestController
@RequestMapping("/api/vi")
public class ClinicalTrialController {
	
	@Autowired
	private ClinicalTrialRespository ctrepository;
	
	//get diseasesgroup 
	@GetMapping("/clinicaltrial")
	public List<String> getDiseaseGroup(){
		//List<ClinicalTrial> clinicaltrial = ctrepository.findBydiseasegroup();
		return (List<String>) ctrepository.findBydiseasegroup();
	}
	
	//get list of diseases given the disease group
	@GetMapping("/clinicaltrialdiseases")
	public List<String> getDiseases(String diseasegroup){
		return (List<String>) ctrepository.findAlldiseasesbygroup(diseasegroup);
	}
	
	//get the list of trials for diseases given the disease name
	@GetMapping("/clinicaltrialnames")
	public ResponseEntity<List<ClinicalTrial>> getTrialNames(String disease){
		List<ClinicalTrial> clinicaltrial =ctrepository.findAllTrialBydisease(disease);
		return ResponseEntity.ok().body(clinicaltrial);
	}
	
	//get the trial info given the trial name
	@GetMapping("/clinicaltrialname")
	public ResponseEntity<ClinicalTrial> getTrialInfo(String name){
		ClinicalTrial clinicaltrial = ctrepository.findTrialByname(name);
		return ResponseEntity.ok().body(clinicaltrial);
	}
	
	//get all the trial names for listing purpose
	@GetMapping("/clinicaltrials")
	public List<String> getTrials(){
		return (List<String>) ctrepository.findAllTrials();
		
	}
	
	//custom 
	@GetMapping("clinicaltrialpatients")
	public List<Patient> getPatientsList(String name){
		return (List<Patient>) ctrepository.findPatients(name);	}
}
