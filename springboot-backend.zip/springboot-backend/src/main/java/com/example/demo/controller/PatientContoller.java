package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Patient;
import com.example.demo.repository.PatientRespository;

@RestController
@RequestMapping("/api/vi/")
public class PatientContoller {
	
	@Autowired
	private PatientRespository patientrepository;
		
	//get all patients
	@GetMapping("/Patients")
	public List<Patient> getAllPatients(){
		return (List<Patient>) patientrepository.findAll();
	}
	
	//creating patient rest api
	@PostMapping("/Patient")
	public Patient RegisterPatient(@RequestBody Patient patient ) {
		return patientrepository.save(patient);
	}
	

	/*
	//get patient by user_id- i.e id
	@GetMapping("/Patient/user_id")
	public ResponseEntity<List<Patient>> getPatientById(@RequestParam String user_id){
		
	    // .orElseThrow(() -> new ResourceNotFound("Patient not found for this id :: " + user_id));
	    return new ResponseEntity<List<Patient>>(patientrepository.findByuser_id(user_id),HttpStatus.OK);
	}
	
	
	//@RequestMapping(value = "/Patient/{user_id}" , method = RequestMethod.GET)
	/*@GetMapping("/Patient/{user_id}")
	public List<Patient> getUser(@PathVariable String user_id) {
	    return patientrepository.findByuser_id(user_id);
	}
	*/
	 @GetMapping("/Patient")
	    public ResponseEntity<Patient> getUsersByUsername(String user_id) {
	            Patient patient= patientrepository.findByUser_id(user_id);
	            return ResponseEntity.ok().body(patient);
	        
	 }
	 //update patient using mrn
	 @PutMapping("/Patient/{mrn}")
	 public ResponseEntity<Patient> updatePatient(@PathVariable String mrn,@RequestBody Patient patientdetails ){
		 Patient patient = patientrepository.findById(mrn);//orElseThrow(() -> new ResourceNotFound("Patient not found for this id :: " + user_id));
		 	patient.setFirst_name(patientdetails.getFirst_name());
		 	patient.setAddress(patientdetails.getAddress());
		 	patient.setLast_name(patientdetails.getLast_name());
		 	patient.setMail(patientdetails.getMail());
		 	patient.setPassword(patientdetails.getPassword());
		 	patient.setUser_id(patientdetails.getUser_id());
		 	patient.setGender(patientdetails.getGender());
		 	patient.setDate_of_birth(patientdetails.getDate_of_birth());
		 	Patient updatePatient = patientrepository.save(patient);
		 	return ResponseEntity.ok(updatePatient);
	 }
	 
	 
	 
	
	    
}
	    

